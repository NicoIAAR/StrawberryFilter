class StrawberryFilter:
    def __init__(self, texto):
        self.texto = texto

    def contar_s(self):
        return self.texto.count('s')

# Uso de la clase
texto = input("Ingrese un texto: ")
contador = StrawberryFilter(texto)
print(f"La letra 's' aparece {contador.contar_s()} veces en el texto.")
